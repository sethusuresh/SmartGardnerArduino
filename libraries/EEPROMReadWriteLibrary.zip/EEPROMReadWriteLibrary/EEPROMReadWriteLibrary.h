#ifndef t1
#define t1

#if (ARDUINO >= 100)
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

class EEPROMReadWriteLibrary{
  public:
    //constructor
    EEPROMReadWriteLibrary(bool displayMsg=false);

    //Methods
    boolean eeprom_write_string(int addr, const char* string);
    boolean eeprom_read_string(int addr, char* buffer, int bufSize);

  private:
    boolean eeprom_is_addr_ok(int addr);
    boolean eeprom_write_bytes(int startAddr, const byte* array, int numBytes);
  
};
#endif
